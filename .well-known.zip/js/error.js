$(document).ready(function() {
  	$(".error").fitText(0.4);
  	$(".desc").fitText(8, {minFontSize: '16px'});
});